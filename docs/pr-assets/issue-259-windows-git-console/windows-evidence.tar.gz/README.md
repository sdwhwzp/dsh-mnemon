# Issue 259 Windows verification

This directory retains the temporary Windows-only validation harness and downloaded evidence. The validation branch is `codex/verify-259-windows-console`; it is separate from the production fix and must not be merged. See `report.md` and `compact-results.json` for the successful results.

The harness compiles `Observer.cs` as a Windows GUI executable, starts Node 22.19.0 with `DETACHED_PROCESS`, and confirms that `AttachConsole(nodePid)` fails with `ERROR_INVALID_HANDLE` (6). This is required to establish that Node is a console-free parent, as in a GUI host. A `CREATE_NEW_CONSOLE` positive control must expose a visible Windows console before the A/B result is accepted.

The observer polls Win32 `EnumWindows` and requires `IsWindowVisible`, nonzero bounds, no DWM cloaking, and no minimization. It records new console-class windows and ignores windows that already existed before each phase. The two trials alternate baseline/fixed. Each trial invokes the actual `resolveGitBranch()` source 100 times against a real Git fixture, plus valid padded paths, absent and blank inputs, detached HEAD, non-repositories, and missing directories.

The exact baseline revision is `6da061e8fa51a30ed50c6fff2a4cadcddf7a4a6a`; source blob `eca1a05ed7fc1b382ed31ccdcbadfbc800afba64`.
The fixed source matches production fix revision `1a9d455004c9204a74b87c920d81b67b3f7b954f`; source blob `340e4817a695d4807142e12d09bd70e792cec847`. The production fix branch was not published by this validation task. The validation branch checks that its source matches that blob and extracts raw Git blobs for import with Node's type stripping.

Run on Windows with Node 22.19.0 and Git installed:

```powershell
./scripts/issue-259-windows/run.ps1
```

Actions downloads used:

```sh
gh run download RUN_ID --repo omdsh-dev/dsh-mnemon --name issue-259-windows-evidence --dir /tmp/dsh-mnemon-bug-goal-20260917/windows/run-RUN_ID
```

Earlier attempts are retained for audit:

- `35239926966`: compiler source path error, no behavioral test performed.
- `35240221147`: Windows desktop and positive visibility control confirmed, but `CREATE_NO_WINDOW` did not establish a console-free parent (`AttachConsole` succeeded). Correctly rejected as A/B evidence; baseline/fixed behavior assertions themselves passed. Its screenshot is an unsanitized full ephemeral runner desktop and is not the preferred shareable screenshot.

Authoritative API references:

- [Node 22.19 child_process.execFileSync](https://nodejs.org/download/release/v22.19.0/docs/api/child_process.html#child_processexecfilesyncfile-args-options): `windowsHide` controls the subprocess console window and defaults to false.
- [AttachConsole](https://learn.microsoft.com/en-us/windows/console/attachconsole): error 6 identifies a target process with no console.
- [Process creation flags](https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags): `DETACHED_PROCESS` prevents inheriting the parent's console.
- [IsWindowVisible](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-iswindowvisible): visibility uses `WS_VISIBLE`; an obscured window can still be visible. Enumeration therefore demonstrates visible console window creation, not necessarily focus theft or physical human observation.

The GitHub runner is Windows Server, not the reporter's Windows 11 DSH Desktop installation. This validation tests the real Windows process-launch mechanism and the actual source function, not the full Electron session-switch UI.

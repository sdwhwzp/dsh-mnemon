import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/dsh-mnemon-bug-goal-20260917/windows')
RUNS = [35240525857, 35241111560]
summary = {'issue': 259, 'runs': []}
for run_id in RUNS:
    directory = ROOT / f'run-{run_id}'
    if not directory.exists():
        continue
    metadata = json.loads((directory / 'metadata.json').read_text())
    observation = json.loads((directory / 'windows-observation.json').read_text())
    for variant in ('baseline', 'fixed'):
        source = (directory / f'{variant}.ts').read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(source)).encode() + b'\0' + source).hexdigest()
        assert blob == metadata[f'{variant}Blob']
    run = {
        'id': run_id,
        'url': f'https://github.com/omdsh-dev/dsh-mnemon/actions/runs/{run_id}',
        'metadata': metadata,
        'observerConsoleHandle': observation['observerConsoleHandle'],
        'userInteractive': observation['userInteractive'],
        'screenBounds': observation['screenBounds'],
        'sourceBlobsVerifiedFromArtifactBytes': True,
        'phases': [],
    }
    for phase in observation['phases']:
        worker = json.loads((directory / f"{phase['phase']}-result.json").read_text())
        row = {key: phase[key] for key in ('phase', 'flags', 'checkedConsole', 'nodeHadConsole', 'attachError', 'exitCode', 'samples', 'newVisibleConsoleWindowCount')}
        row['windowClasses'] = dict(collections.Counter(window['class'] for window in phase['newVisibleConsoleWindows']))
        row['probes'] = worker.get('probes')
        row['branch'] = worker.get('branch')
        row['behaviors'] = worker.get('behaviors')
        row['success'] = worker['success']
        row['screenshot'] = str(directory / f"{phase['phase']}-desktop.png") if phase.get('screenshotCaptured') else None
        row['screenshotObservation'] = phase.get('screenshotObservation')
        assert phase['exitCode'] == 0 and worker['success']
        if phase['phase'] != 'positive-control':
            assert phase['checkedConsole'] and not phase['nodeHadConsole'] and phase['attachError'] == 6
            if phase['phase'].startswith('fixed'):
                assert phase['newVisibleConsoleWindowCount'] == 0
            else:
                assert phase['newVisibleConsoleWindowCount'] > 0
        else:
            assert phase['newVisibleConsoleWindowCount'] > 0
        run['phases'].append(row)
    summary['runs'].append(run)
(ROOT / 'compact-results.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps([{ 'id': run['id'], 'counts': {phase['phase']: phase['newVisibleConsoleWindowCount'] for phase in run['phases']} } for run in summary['runs']], indent=2))

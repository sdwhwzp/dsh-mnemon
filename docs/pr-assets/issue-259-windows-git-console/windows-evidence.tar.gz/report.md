# Issue 259 — actual Windows A/B evidence / Windows 实测证据

The actual baseline `resolveGitBranch()` created visible Windows Terminal windows from a console-free Node parent. The exact fixed source created none. All branch and fallback checks passed in both variants.

已在真实 Windows 环境复现：无控制台的 Node 父进程调用原始 `resolveGitBranch()` 时产生可见终端窗口；使用修复后的同一函数时，新增可见窗口为零。修复前后的分支返回值和回退行为均通过验证。

| Run / 实验 | Positive control / 阳性对照 | Baseline trial 1 / 修复前 1 | Fixed trial 1 / 修复后 1 | Baseline trial 2 / 修复前 2 | Fixed trial 2 / 修复后 2 |
| --- | ---: | ---: | ---: | ---: | ---: |
| [Primary observation / 主观测](https://github.com/omdsh-dev/dsh-mnemon/actions/runs/35240525857) | 1 | 105 | 0 | 104 | 0 |
| [Screenshot observation / 截图复验](https://github.com/omdsh-dev/dsh-mnemon/actions/runs/35241111560) | 1 | 105 | 0 | 105 | 0 |

Counts are distinct visible console windows, not process counts. Each trial performs 100 normal branch probes plus four probes that spawn Git: a padded valid path, detached HEAD, a non-repository, and a missing path. Absent and blank inputs are also checked. Each baseline trial observed 104 Windows Terminal windows; the 105-window trials additionally observed one classic `ConsoleWindowClass` window.

计数对象是新增的可见控制台窗口，不等同于进程数量。每轮包括 100 次正常分支查询，以及带空白的有效路径、分离 HEAD、非仓库目录、不存在目录共 4 次会启动 Git 的查询；另验证空值和空白输入。每轮修复前均观测到 104 个 Windows Terminal 窗口；105 的轮次额外捕获到 1 个传统控制台窗口。

## Environment and guards / 环境与判定条件

- GitHub-hosted `windows-latest`: Windows Server 2025 Datacenter, version `10.0.26100`, image `win25-vs2026` / `20260907.229.1`.
- Node `v22.19.0`, libuv `1.51.0`, executable `C:\hostedtoolcache\windows\node\22.19.0\x64\node.exe`.
- Git `2.55.0.windows.5`, executable `C:\Program Files\Git\bin\git.exe`.
- The observer is compiled as a Windows GUI executable and has `GetConsoleWindow() == 0`.
- Every A/B Node parent starts with `DETACHED_PROCESS`; `AttachConsole(nodePid)` returned false with error `6` (`ERROR_INVALID_HANDLE`) in all eight successful A/B phases, confirming no parent console.
- `EnumWindows` polling counted only new console-class windows with `IsWindowVisible == true`, positive bounds, no DWM cloaking, and no minimization. The positive control uses `CREATE_NEW_CONSOLE` and exposed a real Windows Terminal window in both runs.
- Both variants returned `console-probe` for the fixture and padded fixture path. Absent/blank input, detached HEAD, non-repositories, and nonexistent paths returned `undefined`. All child processes exited with code zero.
- Artifacts include exact raw source blobs, and the local summary script recomputed and verified their Git object hashes from downloaded bytes.

## Exact revisions / 精确版本

| Item / 项目 | Value / 值 |
| --- | --- |
| Baseline revision | `6da061e8fa51a30ed50c6fff2a4cadcddf7a4a6a` |
| Fixed production revision | `1a9d455004c9204a74b87c920d81b67b3f7b954f` |
| Baseline source blob | `eca1a05ed7fc1b382ed31ccdcbadfbc800afba64` |
| Fixed source blob | `340e4817a695d4807142e12d09bd70e792cec847` |
| Baseline source SHA-256 | `1cafeeb141e84721fd1e42afb1a7f546593c32c6535cf5bfeda12fa1abb34473` |
| Fixed source SHA-256 | `b66c292271c41361ca21214b673d89bb5fa208bc8ddca683adf5f8fc5487a00f` |
| Primary validation commit | `f5979b854b22a47c1dd77434bb7cacc2a40e5ce7` |
| Screenshot validation commit | `b81ccd541e93644d3ae2106a8163acdce654534c` |

The fixed source in both validation commits is byte-identical to the source file in the fixed production revision. Only the temporary validation branch was pushed. No validation workflow or harness was added to the production branch.

## Selected screenshot pair / 选用截图

The screenshot run temporarily minimized one preexisting ephemeral runner console window and restored it afterward. It captured a real baseline flash while the window was still visible, then captured the fixed phase approximately one second after it started, while real Git probes were running. The baseline screenshot catches the short window opening frame before Terminal finishes painting; Git was not artificially delayed. Focus was set for capture, so these images do not independently establish focus theft. Zero-window evidence comes from continuous enumeration over each entire fixed phase, not from a single screenshot.

截图复验临时最小化了 1 个既有的临时 runner 控制台窗口，结束后恢复。修复前截图捕获的是窗口仍可见时的真实闪现帧，Terminal 尚未完成绘制；没有人为延长 Git 运行时间。修复后截图在查询循环仍运行时拍摄。零窗口结论来自整个阶段的持续枚举，而非单张截图。截图时设置了前台窗口，因此不以这些图片单独证明焦点被抢占。

- Before / 修复前: `run-35241111560/baseline-1-desktop.png`
- After / 修复后: `run-35241111560/fixed-1-desktop.png`
- Positive visibility control / 可见窗口阳性对照: `run-35241111560/positive-control-desktop.png`

## Reusable evidence links / 可复用链接

- [Primary job](https://github.com/omdsh-dev/dsh-mnemon/actions/runs/35240525857/job/105267481265)
- [Screenshot job](https://github.com/omdsh-dev/dsh-mnemon/actions/runs/35241111560/job/105269485281)
- [Pinned workflow](https://github.com/omdsh-dev/dsh-mnemon/blob/b81ccd541e93644d3ae2106a8163acdce654534c/.github/workflows/issue-259-windows-validation.yml)
- [Pinned Win32 observer](https://github.com/omdsh-dev/dsh-mnemon/blob/b81ccd541e93644d3ae2106a8163acdce654534c/scripts/issue-259-windows/Observer.cs)
- [Pinned Windows runner script](https://github.com/omdsh-dev/dsh-mnemon/blob/b81ccd541e93644d3ae2106a8163acdce654534c/scripts/issue-259-windows/run.ps1)
- [Pinned real-module worker](https://github.com/omdsh-dev/dsh-mnemon/blob/b81ccd541e93644d3ae2106a8163acdce654534c/scripts/issue-259-windows/worker.mjs)

Run from the validation checkout on Windows with Node and Git installed:

```powershell
./scripts/issue-259-windows/run.ps1
```

Full raw artifacts remain in GitHub Actions (`issue-259-windows-evidence`, 14-day retention) and local `run-*` directories. Compact shareable results are `compact-results.json`; harness copies are in `harness/`.

## Scope / 范围

This is independently observed Windows process-launch and real-source-function evidence. It does not claim to replay the full DSH Desktop Electron conversation-switch UI on the reporter's Windows 11 machine. The reporter's Windows 11 session-switch observations remain separate evidence. The unmanifested .NET observer reports the legacy compatibility OS version `6.2.9200`; the authoritative OS identity above comes from `Win32_OperatingSystem`.

这是独立取得的真实 Windows 进程启动和源函数验证证据；不声称已在报告者的 Windows 11 DSH Desktop / Electron 环境重放完整会话切换。报告者提供的 Windows 11 观察记录仍单独归类。
